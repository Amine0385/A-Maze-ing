from mazegen.generator import MazeGenerator

__all__ = ['mazegen']


